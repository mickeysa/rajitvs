﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace outsourcing.rajitservices.Models
{
    public class Career
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}